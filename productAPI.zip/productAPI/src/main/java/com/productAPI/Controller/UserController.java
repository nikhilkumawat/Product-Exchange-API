package com.productAPI.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.productAPI.Entity.UserEntity;
import com.productAPI.Service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;
	
	@GetMapping("/users")
	public List<UserEntity> fetchAllUsers(){
		List<UserEntity> userEntities = userService.fetchAllUsers();
		return userEntities;
	}
	
	@GetMapping("/users/{userId}")
	public UserEntity fetchUserByUserId(@PathVariable String userId){
		UserEntity userEntity = userService.fetchUserByUserId(Long.parseLong(userId));
		return userEntity;
	}
	
	@PostMapping("users")
	public UserEntity addNewUser(@RequestBody UserEntity entity) {
		UserEntity userEntity = userService.addNewUser(entity);
		return userEntity;
	}
	
	@DeleteMapping("/users/{userId}")
	public UserEntity deleteUserByUserId(@PathVariable String userId) {
		UserEntity userEntity = userService.deleteUserByUserId(Long.parseLong(userId));
		return userEntity;
	}
	
}
