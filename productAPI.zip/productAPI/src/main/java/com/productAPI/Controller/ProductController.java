package com.productAPI.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.productAPI.Entity.ProductEntity;
import com.productAPI.Service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/products")
	public List<ProductEntity> fetchAllProducts(){
		List<ProductEntity> productEntities = productService.fetchAllProducts();
		return productEntities;
	}
	
	@GetMapping("/products/{productId}")
	public ProductEntity fetchProductByProductId(@PathVariable String productId){
		ProductEntity productEntity = productService.fetchProductByProductId(Long.parseLong(productId));
		return productEntity;
	}
	
	@PostMapping("/products")
	public ProductEntity addNewProduct(@RequestBody ProductEntity entity) {
		ProductEntity productEntity = productService.addNewProduct(entity);
		return productEntity;
	}
	
	@DeleteMapping("/products/{productId}")
	public ProductEntity deleteProductByProductId(@PathVariable String productId) {
		ProductEntity productEntity = productService.deleteProductByProductId(Long.parseLong(productId));
		return productEntity;
	}
	
}
