package com.productAPI.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productAPI.Entity.UserEntity;
import com.productAPI.Repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public List<UserEntity> fetchAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	public UserEntity fetchUserByUserId(long userId) {
		if(!userRepository.existsById(userId)) {
			return null;
		}
		return userRepository.findById(userId).get();
	}

	public UserEntity addNewUser(UserEntity entity) {
		// TODO Auto-generated method stub
		return userRepository.save(entity);
	}

	public UserEntity deleteUserByUserId(long userId) {
		if(!userRepository.existsById(userId)) {
			return null;
		}
		UserEntity UserEntity = userRepository.findById(userId).get();
		userRepository.delete(UserEntity);
		return UserEntity;
	}
	
	
}
