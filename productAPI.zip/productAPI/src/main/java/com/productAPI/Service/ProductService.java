package com.productAPI.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productAPI.Entity.ProductEntity;
import com.productAPI.Repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	public List<ProductEntity> fetchAllProducts(){
		return productRepository.findAll();
	}

	public ProductEntity addNewProduct(ProductEntity entity) {
		return productRepository.save(entity);
	}

	public ProductEntity fetchProductByProductId(long productId) {
		if(!productRepository.existsById(productId)) {
			return null;
		}
		return productRepository.findById(productId).get();
	}

	public ProductEntity deleteProductByProductId(long productId) {
		// TODO Auto-generated method stub
		if(!productRepository.existsById(productId)) {
			return null;
		}
		ProductEntity productEntity = productRepository.findById(productId).get();
		productRepository.delete(productEntity);
		return productEntity;
	}
}
